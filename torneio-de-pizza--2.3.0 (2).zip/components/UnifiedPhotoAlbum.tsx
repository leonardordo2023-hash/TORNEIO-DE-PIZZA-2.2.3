
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { PizzaData, MediaItem, MediaCategory, SocialData, UserAccount, Reply, Comment } from '../types';
import { processMediaFile } from '../services/imageService';
import { Camera, Image as ImageIcon, Loader2, Trash2, Download, Video, Trophy, Users, Pizza, Heart, Send, User, X, Pencil, Check, MessageCircle, Type, ChevronLeft, ChevronRight, ZoomIn, ZoomOut, LayoutGrid, Grip, Filter, ArrowUp, ArrowDown, Film, Plus, ShieldCheck, Clock } from 'lucide-react';
import JSZip from 'jszip';
import { Language, translations } from '../services/translations';

interface UnifiedPhotoAlbumProps {
  pizzas: PizzaData[];
  userId: string;
  onAddMedia: (id: number | string, item: MediaItem) => void;
  onDeleteMedia: (id: number | string, mediaId: string) => void;
  socialData: SocialData;
  onAddComment: (mediaId: string, text: string) => void;
  onEditComment: (mediaId: string, commentId: string, newText: string) => void;
  onDeleteComment: (mediaId: string, commentId: string) => void;
  onReact: (mediaId: string, emoji: string) => void;
  onCommentReact: (mediaId: string, commentId: string, emoji: string) => void;
  onUpdateCaption: (id: number | string, mediaId: string, caption: string) => void;
  language: Language;
  currentUser: UserAccount;
}

const getRelativeTime = (timestamp: number | undefined) => {
  if (!timestamp) return 'Recente';
  const diffInSeconds = Math.floor((Date.now() - timestamp) / 1000);
  if (diffInSeconds < 60) return 'agora';
  if (diffInSeconds < 3600) return `há ${Math.floor(diffInSeconds / 60)} min`;
  if (diffInSeconds < 86400) return `há ${Math.floor(diffInSeconds / 3600)} h`;
  const date = new Date(timestamp);
  return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
};

export const UnifiedPhotoAlbum: React.FC<UnifiedPhotoAlbumProps> = ({ 
    pizzas, userId, onAddMedia, onDeleteMedia, 
    socialData, onAddComment, onEditComment, onDeleteComment, onReact, onCommentReact, onUpdateCaption, language, currentUser
}) => {
  const t = translations[language];
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isZipping, setIsZipping] = useState(false);
  const [activeCategory, setActiveCategory] = useState<MediaCategory>('pizza');
  const [commentInput, setCommentInput] = useState<Record<string, string>>({});
  const [showReactions, setShowReactions] = useState<string | null>(null);
  
  const [viewMode, setViewMode] = useState<'standard' | 'compact'>('standard');
  const [filterType, setFilterType] = useState<'all' | 'image' | 'video'>('all');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');
  const [selectedMediaId, setSelectedMediaId] = useState<string | null>(null);
  const [isZoomed, setIsZoomed] = useState(false);
  const [activeMenu, setActiveMenu] = useState<string | null>(null); 
  const [editingComment, setEditingComment] = useState<{id: string, text: string} | null>(null);
  const [showCommentsSidebar, setShowCommentsSidebar] = useState(window.innerWidth > 768); 
  
  const commentsEndRef = useRef<HTMLDivElement>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadCaption, setUploadCaption] = useState('');
  const [stagedFiles, setStagedFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<{url: string, type: string}[]>([]);
  const [editingCaption, setEditingCaption] = useState<string | null>(null); 
  const [captionText, setCaptionText] = useState('');

  const isAdmin = userId.toLowerCase() === '@leonardo';

  const allMedia = pizzas.flatMap(p => (p.media || [])
    .filter(m => m.hiddenFromFeed === true) 
    .map(m => ({ ...m, pizzaId: p.id }))
  );
  
  const filteredMedia = allMedia
    .filter(m => m.category === activeCategory)
    .filter(m => filterType === 'all' || m.type === filterType)
    .sort((a, b) => sortOrder === 'desc' ? b.date - a.date : a.date - b.date);

  const selectedMediaIndex = filteredMedia.findIndex(m => m.id === selectedMediaId);
  const selectedMedia = selectedMediaIndex >= 0 ? filteredMedia[selectedMediaIndex] : null;

  useEffect(() => {
    if (showCommentsSidebar && selectedMediaId) {
        const timer = setTimeout(() => commentsEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 500);
        return () => clearTimeout(timer);
    }
  }, [showCommentsSidebar, selectedMediaId, socialData.comments]);

  const handleOpenMedia = (mediaId: string) => {
      setSelectedMediaId(mediaId);
      setIsZoomed(false);
      if (window.innerWidth < 768) setShowCommentsSidebar(false);
  };

  const handleNext = useCallback(() => {
      if (selectedMediaIndex < filteredMedia.length - 1) {
          setSelectedMediaId(filteredMedia[selectedMediaIndex + 1].id);
          setIsZoomed(false);
      }
  }, [selectedMediaIndex, filteredMedia]);

  const handlePrev = useCallback(() => {
      if (selectedMediaIndex > 0) {
          setSelectedMediaId(filteredMedia[selectedMediaIndex - 1].id);
          setIsZoomed(false);
      }
  }, [selectedMediaIndex, filteredMedia]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    const fileArray = Array.from(files).filter((file: any) => file.type.startsWith('image/')) as File[];
    if (fileArray.length === 0) return;
    setStagedFiles(prev => [...prev, ...fileArray]);
    const newPreviews = fileArray.map((file: File) => ({ url: URL.createObjectURL(file), type: 'image' }));
    setPreviews(prev => [...prev, ...newPreviews]);
  };

  const handlePostSubmit = async () => {
    const targetId = pizzas[0]?.id;
    if (!targetId || stagedFiles.length === 0) return;
    setIsUploading(true);
    setUploadProgress(0);
    try {
        for (let i = 0; i < stagedFiles.length; i++) {
            const file = stagedFiles[i];
            const { url, type } = await processMediaFile(file, 50, (percent) => {
                const totalPercent = Math.round(((i / stagedFiles.length) * 100) + (percent / stagedFiles.length));
                setUploadProgress(totalPercent);
            });
            onAddMedia(targetId, { 
                id: Math.random().toString(36).substring(2, 15), 
                url, type, category: activeCategory, 
                date: Date.now(), caption: uploadCaption, hiddenFromFeed: true
            });
        }
        setIsUploadModalOpen(false);
        setUploadCaption('');
        setStagedFiles([]);
        setPreviews([]);
    } catch (err) { alert(err instanceof Error ? err.message : "Erro no processamento."); } finally { setIsUploading(false); }
  };

  const handleDownloadAll = async () => {
    if (filteredMedia.length === 0) return;
    setIsZipping(true);
    try {
        const zip = new JSZip();
        filteredMedia.forEach((item, index) => { 
          const base64Data = item.url.split(',')[1]; 
          if (base64Data) zip.file(`torneio-${activeCategory}-${index + 1}.jpg`, base64Data, { base64: true }); 
        });
        const content = await zip.generateAsync({ type: "blob" });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(content);
        link.download = `album-${activeCategory}.zip`;
        link.click();
    } catch (error) { alert("Erro ZIP."); } finally { setIsZipping(false); }
  };

  const reactions = [{ label: 'Amei', emoji: '❤️' }, { label: 'Delícia', emoji: '😋' }, { label: 'Uau', emoji: '😮' }, { label: 'Top', emoji: '🔥' }, { label: 'Pizza', emoji: '🍕' }];

  return (
    <div className="max-w-6xl mx-auto bg-transparent flex flex-col min-h-[600px] animate-fade-in-up">
      
      {/* LIGHTBOX MODAL - DESIGN PREMIUM */}
      {selectedMedia && (
        <div className="fixed inset-0 z-[300] bg-slate-950/98 glass flex items-center justify-center p-0 md:p-6 animate-in fade-in duration-300" onClick={() => setSelectedMediaId(null)}>
          <div className="relative w-full h-full max-w-7xl bg-white dark:bg-slate-900 rounded-none md:rounded-[3rem] shadow-5xl overflow-hidden flex flex-col md:flex-row transition-all duration-500 border border-white/10" onClick={(e) => e.stopPropagation()}>
            
            {/* ÁREA DA MÍDIA */}
            <div className={`relative flex flex-col flex-1 bg-black overflow-hidden group transition-all duration-700 ${showCommentsSidebar ? 'md:w-2/3' : 'md:w-full'}`}>
              
              {/* Controles de Topo */}
              <div className="absolute top-0 left-0 right-0 p-6 z-30 flex justify-between items-center bg-gradient-to-b from-black/80 via-black/40 to-transparent">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-xl rotate-3">
                    <ImageIcon size={24} />
                  </div>
                  <div className="text-left">
                    <span className="block font-black text-white text-lg tracking-tighter uppercase leading-none">Galeria Oficial</span>
                    <span className="text-[10px] font-black text-white/60 uppercase tracking-widest mt-1 flex items-center gap-1.5"><Clock size={10}/> {getRelativeTime(selectedMedia.date)}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                   {isAdmin && (
                      <div className="flex gap-2">
                        <button onClick={() => { setEditingCaption(selectedMedia.id); setCaptionText(selectedMedia.caption || ''); }} className="p-3 bg-white/10 hover:bg-indigo-600 text-white rounded-2xl backdrop-blur-md border border-white/20 transition-all shadow-xl"><Pencil size={20} /></button>
                        <button onClick={() => window.confirm("Excluir foto?") && (onDeleteMedia(selectedMedia.pizzaId, selectedMedia.id), setSelectedMediaId(null))} className="p-3 bg-white/10 hover:bg-red-600 text-white rounded-2xl backdrop-blur-md border border-white/20 transition-all shadow-xl"><Trash2 size={20} /></button>
                      </div>
                   )}
                   <button onClick={() => setSelectedMediaId(null)} className="p-3 bg-white/20 hover:bg-white/40 text-white rounded-2xl transition-all"><X size={24}/></button>
                </div>
              </div>

              {/* Botões de Navegação Ultra-Acessíveis */}
              <button onClick={handlePrev} className="absolute left-6 top-1/2 -translate-y-1/2 p-5 bg-white/5 hover:bg-white/20 text-white rounded-full glass transition-all z-20 opacity-0 group-hover:opacity-100 disabled:opacity-0" disabled={selectedMediaIndex === 0}><ChevronLeft size={32}/></button>
              <button onClick={handleNext} className="absolute right-6 top-1/2 -translate-y-1/2 p-5 bg-white/5 hover:bg-white/20 text-white rounded-full glass transition-all z-20 opacity-0 group-hover:opacity-100 disabled:opacity-0" disabled={selectedMediaIndex === filteredMedia.length - 1}><ChevronRight size={32}/></button>

              {/* Imagem Central */}
              <div className="flex-1 flex items-center justify-center p-4">
                <img 
                  src={selectedMedia.url} 
                  className={`max-w-full max-h-full object-contain transition-transform duration-700 ease-out select-none rounded-xl shadow-2xl ${isZoomed ? 'scale-150 cursor-zoom-out' : 'scale-100 cursor-zoom-in'}`}
                  onClick={() => setIsZoomed(!isZoomed)}
                />
              </div>

              {/* Legenda Flutuante */}
              {selectedMedia.caption && !isZoomed && (
                <div className="absolute bottom-10 left-10 right-10 z-20">
                  <div className="max-w-2xl mx-auto p-8 rounded-[2.5rem] bg-black/60 glass border border-white/20 shadow-4xl text-center">
                    <p className="text-xl md:text-3xl font-black text-white leading-tight tracking-tight uppercase">"{selectedMedia.caption}"</p>
                  </div>
                </div>
              )}
            </div>

            {/* BARRA LATERAL DE COMENTÁRIOS / REAÇÕES */}
            <div className={`flex flex-col bg-white dark:bg-slate-900 overflow-hidden transition-all duration-500 border-l border-slate-100 dark:border-slate-800 ${showCommentsSidebar ? 'w-full md:w-[400px]' : 'w-0'}`}>
               <div className="p-6 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center">
                  <h3 className="font-black text-xs uppercase tracking-widest text-slate-500 flex items-center gap-2">
                    <MessageCircle size={18} className="text-indigo-500" /> Interações
                  </h3>
                  <button onClick={() => setShowCommentsSidebar(false)} className="md:hidden p-2 bg-slate-100 dark:bg-slate-800 rounded-xl"><X size={16}/></button>
               </div>
               
               <div className="p-6 border-b border-slate-50 dark:border-slate-800">
                  <div className="flex flex-wrap gap-2">
                    {reactions.map(r => (
                      <button key={r.label} onClick={() => onReact(selectedMedia.id, r.emoji)} className={`p-4 rounded-3xl transition-all hover:scale-110 active:scale-90 text-3xl border-2 ${socialData.likes[selectedMedia.id]?.[currentUser.nickname] === r.emoji ? 'bg-indigo-50 border-indigo-200' : 'bg-slate-50 dark:bg-slate-800 border-transparent'}`}>
                        {r.emoji}
                      </button>
                    ))}
                  </div>
               </div>

               <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-6">
                  {socialData.comments[selectedMedia.id]?.length ? (
                    socialData.comments[selectedMedia.id].map(c => (
                      <div key={c.id} className="bg-slate-50 dark:bg-slate-800/50 p-5 rounded-[2rem] relative group border border-transparent hover:border-slate-200 transition-all">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-[10px] font-black">{c.user.charAt(1).toUpperCase()}</div>
                          <span className="font-black text-indigo-600 dark:text-indigo-400 text-[10px] uppercase tracking-widest">{c.user}</span>
                        </div>
                        <p className="text-sm font-bold text-slate-700 dark:text-slate-200 leading-relaxed">{c.text}</p>
                      </div>
                    ))
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center opacity-20 text-center space-y-4">
                      <MessageCircle size={64}/>
                      <p className="text-xs font-black uppercase tracking-[0.3em]">Ninguém comentou ainda</p>
                    </div>
                  )}
                  <div ref={commentsEndRef}/>
               </div>

               <div className="p-6 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex gap-3">
                    <input 
                      className="flex-1 bg-white dark:bg-slate-900 px-6 py-4 rounded-3xl border-2 border-slate-200 dark:border-slate-700 font-bold text-sm outline-none focus:border-indigo-500 transition-all" 
                      placeholder="Diga algo..." 
                      value={commentInput[selectedMedia.id] || ''}
                      onChange={e => setCommentInput({...commentInput, [selectedMedia.id]: e.target.value})}
                      onKeyDown={e => e.key === 'Enter' && (onAddComment(selectedMedia.id, commentInput[selectedMedia.id]), setCommentInput({...commentInput, [selectedMedia.id]: ''}))}
                    />
                    <button onClick={() => (onAddComment(selectedMedia.id, commentInput[selectedMedia.id]), setCommentInput({...commentInput, [selectedMedia.id]: ''}))} className="p-4 bg-indigo-600 text-white rounded-3xl shadow-xl hover:bg-indigo-700 active:scale-95 transition-all"><Send size={24}/></button>
                  </div>
               </div>
            </div>
          </div>
        </div>
      )}

      {/* FERRAMENTAS DE TOPO DA GALERIA */}
      <div className="p-6 md:p-10 mb-6 bg-white dark:bg-slate-900 rounded-[3rem] shadow-2xl shadow-black/5 border border-slate-200/50 dark:border-slate-800/50">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
            <div className="flex items-center gap-5">
                <div className="w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-[1.8rem] flex items-center justify-center text-white shadow-2xl rotate-3 animate-float">
                  <ImageIcon size={32} />
                </div>
                <div>
                  <h2 className="text-4xl font-black uppercase tracking-tighter text-slate-900 dark:text-white leading-none">{t.album}</h2>
                  <div className="flex items-center gap-3 mt-3">
                    <span className="px-3 py-1 bg-indigo-50 dark:bg-indigo-900/30 rounded-full text-[10px] font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest border border-indigo-100 dark:border-indigo-800">{filteredMedia.length} Itens</span>
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-200 dark:bg-slate-700"></span>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Atualizado agora</span>
                  </div>
                </div>
            </div>

            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                <div className="flex bg-slate-100 dark:bg-slate-800 p-1.5 rounded-[1.5rem] border border-slate-200/50 dark:border-slate-700/50">
                   {['all', 'image'].map(type => (
                     <button key={type} onClick={() => setFilterType(type as any)} className={`px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${filterType === type ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-md scale-105' : 'text-slate-400 hover:text-slate-600'}`}>{type === 'all' ? 'Todos' : 'Fotos'}</button>
                   ))}
                </div>
                
                <button onClick={handleDownloadAll} disabled={isZipping} className="flex-1 md:flex-none flex items-center justify-center gap-2.5 px-6 py-4 bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-800 rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest text-slate-600 dark:text-slate-300 hover:border-indigo-500 active:scale-95 transition-all shadow-sm">
                  {isZipping ? <Loader2 size={16} className="animate-spin" /> : <Download size={16} />} <span>Baixar Tudo</span>
                </button>

                {isAdmin && (
                  <button onClick={() => setIsUploadModalOpen(true)} className="flex-1 md:flex-none flex items-center justify-center gap-2.5 px-8 py-4 bg-indigo-600 text-white rounded-[1.5rem] font-black text-[10px] uppercase tracking-widest shadow-2xl shadow-indigo-500/30 hover:bg-indigo-700 active:scale-95 transition-all">
                    <Plus size={18} strokeWidth={3} /> Postar Foto
                  </button>
                )}
            </div>
        </div>

        {/* Categorias Fluidas */}
        <div className="flex gap-3 mt-10 overflow-x-auto no-scrollbar pb-2">
            {[ { id: 'pizza', label: 'Pizzas', icon: <Pizza size={14}/> }, { id: 'champion', label: 'Campeões', icon: <Trophy size={14}/> }, { id: 'team', label: 'Equipe', icon: <Users size={14}/> } ].map((cat) => (
                <button key={cat.id} onClick={() => setActiveCategory(cat.id as any)} className={`flex items-center gap-3 px-8 py-4 rounded-[1.5rem] font-black text-[11px] uppercase tracking-[0.2em] transition-all whitespace-nowrap border-2 ${activeCategory === cat.id ? 'bg-indigo-600 border-indigo-600 text-white shadow-xl shadow-indigo-500/20' : 'bg-slate-50 dark:bg-slate-800/50 border-slate-100 dark:border-slate-800 text-slate-500 hover:border-indigo-400'}`}>
                  {cat.icon} {cat.label}
                </button>
            ))}
        </div>
      </div>

      {/* GRID DE FOTOS - RESPONSIVO E FLUIDO */}
      <div className="px-2 pb-20">
        {filteredMedia.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredMedia.map((item) => (
              <div 
                key={item.id} 
                className="relative aspect-square rounded-[2rem] overflow-hidden group shadow-lg cursor-pointer bg-slate-200 dark:bg-slate-800 border border-slate-200 dark:border-slate-800 hover:-translate-y-2 hover:shadow-3xl transition-all duration-500"
                onClick={() => handleOpenMedia(item.id)}
              >
                <img src={item.url} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-115" loading="lazy" />
                
                {/* Overlay Visual Superior para Admin */}
                {isAdmin && (
                  <div className="absolute top-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-20">
                    <button onClick={(e) => { e.stopPropagation(); if(confirm("Excluir?")) onDeleteMedia(item.pizzaId, item.id); }} className="p-2.5 bg-red-600 text-white rounded-xl shadow-xl active:scale-90"><Trash2 size={16}/></button>
                  </div>
                )}

                {/* Info Overlay Inferior */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/0 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex flex-col justify-end p-6">
                   <div className="flex items-center justify-between text-white">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1.5"><Heart size={16} className="fill-white" /> <span className="text-xs font-black">{Object.keys(socialData.likes[item.id] || {}).length}</span></div>
                        <div className="flex items-center gap-1.5"><MessageCircle size={16} className="fill-white" /> <span className="text-xs font-black">{socialData.comments[item.id]?.length || 0}</span></div>
                      </div>
                      <div className="p-2 bg-white/20 rounded-lg backdrop-blur-md"><Plus size={16}/></div>
                   </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-40 text-center flex flex-col items-center gap-6 opacity-20">
            <ImageIcon size={80}/>
            <p className="text-sm font-black uppercase tracking-[0.4em]">Galeria Vazia</p>
          </div>
        )}
      </div>

      {/* MODAL DE UPLOAD - DESIGN ADAPTÁVEL */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-[400] glass bg-slate-950/80 flex items-center justify-center p-4 animate-in fade-in duration-300">
           <div className="bg-white dark:bg-slate-900 w-full max-w-lg rounded-[3rem] shadow-5xl border border-white/20 overflow-hidden animate-in zoom-in-95">
              <div className="p-8 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center bg-slate-50/50 dark:bg-slate-800/50">
                  <h3 className="text-2xl font-black uppercase tracking-tighter">Nova Mídia</h3>
                  <button onClick={() => setIsUploadModalOpen(false)} className="p-3 bg-slate-200 dark:bg-slate-700 rounded-2xl hover:bg-slate-300 transition-all"><X size={24}/></button>
              </div>
              
              <div className="p-8 space-y-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-[0.2em]">Frase ou Legenda</label>
                    <textarea value={uploadCaption} onChange={e => setUploadCaption(e.target.value)} className="w-full p-6 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-indigo-500 rounded-4xl outline-none font-bold text-lg transition-all shadow-inner dark:text-white" rows={3} placeholder="Escreva algo marcante..." />
                  </div>

                  <div className="space-y-4">
                    <label className="text-[10px] font-black uppercase text-slate-400 ml-2 tracking-[0.2em]">Arquivos</label>
                    {stagedFiles.length > 0 ? (
                      <div className="grid grid-cols-3 gap-3">
                        {previews.map((p, i) => (
                          <div key={i} className="relative aspect-square rounded-2xl overflow-hidden shadow-md border-2 border-white dark:border-slate-800"><img src={p.url} className="w-full h-full object-cover" /></div>
                        ))}
                        <label className="aspect-square border-2 border-dashed border-slate-200 dark:border-slate-700 rounded-2xl flex items-center justify-center cursor-pointer hover:bg-indigo-50 transition-all text-slate-400 hover:text-indigo-500"><input type="file" multiple className="hidden" accept="image/*" onChange={handleFileChange}/><Plus size={24}/></label>
                      </div>
                    ) : (
                      <label className="w-full h-48 border-4 border-dashed border-slate-100 dark:border-slate-800 rounded-[2.5rem] flex flex-col items-center justify-center gap-4 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 transition-all group">
                        <input type="file" multiple className="hidden" accept="image/*" onChange={handleFileChange}/>
                        <div className="p-5 bg-slate-50 dark:bg-slate-800 rounded-full group-hover:scale-110 transition-transform shadow-sm"><Camera size={40} className="text-slate-400 group-hover:text-indigo-500" /></div>
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Selecionar Fotos</span>
                      </label>
                    )}
                  </div>
              </div>

              <div className="p-8 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800">
                  {isUploading && (
                    <div className="mb-6 space-y-2">
                      <div className="flex justify-between text-[10px] font-black uppercase text-indigo-500 tracking-widest"><span>Publicando...</span><span>{uploadProgress}%</span></div>
                      <div className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden shadow-inner"><div className="h-full bg-indigo-500 transition-all duration-300" style={{ width: `${uploadProgress}%` }}/></div>
                    </div>
                  )}
                  <button onClick={handlePostSubmit} disabled={isUploading || stagedFiles.length === 0} className="w-full py-5 bg-indigo-600 text-white rounded-3xl font-black text-xs uppercase tracking-[0.2em] shadow-2xl shadow-indigo-500/30 hover:bg-indigo-700 active:scale-95 disabled:opacity-50 transition-all">
                    {isUploading ? <Loader2 className="animate-spin" size={24}/> : 'Confirmar Postagem'}
                  </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
