

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { PizzaData, getSum, SocialData, MediaItem, UserAccount, Comment } from '../types';
import { Award, Info, Pizza, Heart, MessageCircle, Trash2, User, X, Pencil, Check, Image as ImageIcon, Video, Smile, Loader2, Send, MoreHorizontal, CornerDownRight, BarChart2, ShieldCheck, Megaphone, Newspaper, Trophy, Plus, ListFilter, Paperclip, Camera, Clock, Share2 } from 'lucide-react';
import { processMediaFile } from '../services/imageService';
import { Language, translations } from '../services/translations';

interface NewsFeedProps {
  pizzas: PizzaData[];
  userId: string;
  onAddPhoto: (id: number | string, mediaItem: MediaItem) => void;
  onDeletePhoto: (id: number | string, mediaId: string) => void;
  socialData: SocialData;
  onAddComment: (mediaId: string, text: string) => void;
  onEditComment: (mediaId: string, commentId: string, newText: string) => void;
  onDeleteComment: (mediaId: string, commentId: string) => void;
  onReact: (mediaId: string, emoji: string) => void;
  onCommentReact: (mediaId: string, commentId: string, emoji: string) => void;
  onReplyToComment: (mediaId: string, commentId: string, text: string) => void;
  // Fix: Removed duplicate onReplyReact identifier on line 20-21
  onReplyReact: (mediaId: string, commentId: string, replyId: string, emoji: string) => void;
  onUpdateCaption: (id: number | string, mediaId: string, caption: string) => void;
  language: Language;
  currentUser: UserAccount;
  onPollVote: (pizzaId: number | string, mediaId: string, selectedOptions: string[]) => void;
  mode?: 'news' | 'avisos';
}

const getRelativeTime = (timestamp: number | undefined) => {
  if (!timestamp) return 'Recente';
  const diffInSeconds = Math.floor((Date.now() - timestamp) / 1000);
  if (diffInSeconds < 60) return 'agora';
  if (diffInSeconds < 3600) return `há ${Math.floor(diffInSeconds / 60)} min`;
  if (diffInSeconds < 86400) return `há ${Math.floor(diffInSeconds / 3600)} h`;
  const date = new Date(timestamp);
  return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
};

export const NewsFeed: React.FC<NewsFeedProps> = ({ 
    pizzas, userId, onAddPhoto, onDeletePhoto,
    socialData, onAddComment, onEditComment, onDeleteComment, onReact, onCommentReact, onUpdateCaption, language, currentUser, onReplyToComment, onReplyReact, onPollVote,
    mode = 'news'
}) => {
  const t = translations[language];
  const isAdmin = userId.toLowerCase() === '@leonardo';

  const [expandedComments, setExpandedComments] = useState<Record<string, boolean>>({});
  const [commentInput, setCommentInput] = useState<Record<string, string>>({});
  const [editingPostId, setEditingPostId] = useState<string | null>(null);
  const [tempCaption, setTempCaption] = useState('');
  const [isPostModalOpen, setIsPostModalOpen] = useState(false);
  const [postCaption, setPostCaption] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const feedItems = useMemo(() => {
      return pizzas.flatMap(p => (p.media || [])
        .filter(item => !item.hiddenFromFeed)
        .filter(item => {
            if (mode === 'news') return item.type !== 'poll';
            if (mode === 'avisos') return item.type === 'poll';
            return true;
        })
        .map(item => ({ pizzaId: p.id, item: item }))
      ).sort((a, b) => (b.item.date || 0) - (a.item.date || 0));
  }, [pizzas, mode]);

  const handlePostSubmit = async () => {
      const targetId = pizzas[0]?.id;
      if (!targetId) return;
      setIsUploading(true);
      try {
          let url = '';
          if (selectedFile) {
              const res = await processMediaFile(selectedFile, 50, setUploadProgress);
              url = res.url;
          }
          onAddPhoto(targetId, {
              id: Math.random().toString(36).substring(2, 15),
              url, type: selectedFile ? 'image' : 'news' as any, category: 'pizza',
              date: Date.now(), caption: postCaption
          });
          setIsPostModalOpen(false);
          setPostCaption('');
          setSelectedFile(null);
          setPreviewUrl(null);
      } catch (err) { alert("Erro ao postar."); } finally { setIsUploading(false); }
  };

  return (
    <div className="max-w-md mx-auto space-y-4 pb-20 animate-fade-in-up">
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-md ${mode === 'news' ? 'bg-blue-600' : 'bg-orange-500'} text-white`}>
                {mode === 'news' ? <Newspaper size={18} /> : <Megaphone size={18} />}
            </div>
            <h2 className="text-xl font-black uppercase tracking-tighter text-slate-800 dark:text-white">{mode === 'news' ? t.news : t.avisos}</h2>
        </div>
        {isAdmin && (
          <div className="relative group">
            <button onClick={() => setIsPostModalOpen(true)} className="w-8 h-8 bg-slate-900 text-white rounded-lg flex items-center justify-center shadow-lg active:scale-90 transition-all">
              <Plus size={16} strokeWidth={3} />
            </button>
            <span className="absolute top-full mt-1 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-[8px] font-black px-2 py-0.5 rounded shadow-xl whitespace-nowrap z-50 pointer-events-none uppercase tracking-widest border border-white/10">Novo Post</span>
          </div>
        )}
      </div>

      <div className="space-y-4">
          {feedItems.length === 0 ? (
              <div className="py-12 text-center flex flex-col items-center gap-3 bg-white dark:bg-slate-900/40 rounded-2xl border border-dashed border-slate-200">
                  <Info size={24} className="opacity-20" />
                  <p className="text-slate-400 font-black uppercase text-[9px] tracking-widest">Feed Vazio</p>
              </div>
          ) : (
              feedItems.map(({ pizzaId, item }) => (
                  <div key={item.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden transition-all group">
                      <div className="p-3 flex items-center justify-between">
                          <div className="flex items-center gap-2">
                              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${item.type === 'poll' ? 'bg-orange-50 text-orange-500' : 'bg-slate-900 text-white'}`}>
                                  {item.type === 'poll' ? <ListFilter size={14} /> : <ShieldCheck size={14} />}
                              </div>
                              <div>
                                  <span className="block font-black text-slate-800 dark:text-white text-[11px] uppercase tracking-tighter">{item.type === 'poll' ? 'Enquete' : 'Staff'}</span>
                                  <span className="text-[7px] font-black text-slate-400 uppercase flex items-center gap-1"><Clock size={7}/> {getRelativeTime(item.date)}</span>
                              </div>
                          </div>
                      </div>

                      <div className="px-4 pb-4">
                          {item.caption && <p className="text-slate-800 dark:text-slate-100 font-bold mb-3 text-sm leading-snug tracking-tight">{item.caption}</p>}
                          {item.url && (
                              <div className="rounded-xl overflow-hidden bg-slate-50 shadow-inner">
                                  <img src={item.url} className="w-full object-cover max-h-[250px]" loading="lazy" />
                              </div>
                          )}
                      </div>

                      <div className="px-4 py-2 bg-slate-50/50 border-t border-slate-50 flex items-center justify-between">
                          <div className="flex gap-2">
                            <div className="relative group">
                                <button onClick={() => onReact(item.id, '❤️')} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all active:scale-90 ${socialData.likes[item.id]?.[currentUser.nickname] ? 'text-red-500' : 'text-slate-400'}`}>
                                    <Heart size={14} className={socialData.likes[item.id]?.[currentUser.nickname] ? 'fill-current' : ''} />
                                    <span className="text-[9px] font-black">{Object.keys(socialData.likes[item.id] || {}).length}</span>
                                </button>
                                <span className="absolute top-full mt-1 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-[8px] font-black px-2 py-0.5 rounded shadow-xl whitespace-nowrap z-50 pointer-events-none uppercase tracking-widest border border-white/10">Amei</span>
                            </div>
                            <div className="relative group">
                                <button onClick={() => setExpandedComments(prev => ({...prev, [item.id]: !prev[item.id]}))} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all text-slate-400`}>
                                    <MessageCircle size={14} />
                                    <span className="text-[9px] font-black">{socialData.comments[item.id]?.length || 0}</span>
                                </button>
                                <span className="absolute top-full mt-1 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-[8px] font-black px-2 py-0.5 rounded shadow-xl whitespace-nowrap z-50 pointer-events-none uppercase tracking-widest border border-white/10">Comentários</span>
                            </div>
                          </div>
                      </div>

                      {expandedComments[item.id] && (
                        <div className="bg-slate-50/20 p-4 border-t border-slate-50 animate-in slide-in-from-top-2">
                             <div className="space-y-2 mb-3">
                                {socialData.comments[item.id]?.map(c => (
                                    <div key={c.id} className="bg-white p-2 rounded-xl shadow-sm border border-slate-50 flex flex-col gap-1">
                                        <span className="font-black text-[8px] uppercase text-indigo-500">{c.user}</span>
                                        <p className="font-bold text-[10px] text-slate-700 leading-tight">{c.text}</p>
                                    </div>
                                ))}
                             </div>
                             <div className="flex gap-1.5">
                                <input className="flex-1 bg-white border border-slate-100 rounded-lg px-3 py-2 text-[10px] font-bold outline-none" placeholder="Escreva..." value={commentInput[item.id] || ''} onChange={e => setCommentInput({...commentInput, [item.id]: e.target.value})} onKeyDown={e => e.key === 'Enter' && (onAddComment(item.id, commentInput[item.id]), setCommentInput({...commentInput, [item.id]: ''}))} />
                                <button onClick={() => (onAddComment(item.id, commentInput[item.id]), setCommentInput({...commentInput, [item.id]: ''}))} className="p-2 bg-indigo-600 text-white rounded-lg active:scale-90"><Send size={14} /></button>
                             </div>
                        </div>
                      )}
                  </div>
              ))
          )}
      </div>

      {/* Post Modal */}
      {isPostModalOpen && (
          <div className="fixed inset-0 z-[500] bg-black/80 glass flex items-center justify-center p-4 animate-in fade-in">
              <div className="bg-white dark:bg-slate-900 w-full max-w-sm rounded-[2rem] shadow-5xl border border-white/20 overflow-hidden animate-in zoom-in-95">
                  <div className="p-6 border-b border-slate-50 dark:border-slate-800 flex justify-between items-center bg-slate-50/50">
                      <h3 className="text-lg font-black uppercase tracking-tighter">Novo Staff Post</h3>
                      <button onClick={() => setIsPostModalOpen(false)} className="p-2 bg-slate-200 rounded-lg"><X size={18}/></button>
                  </div>
                  <div className="p-6 space-y-4">
                      <textarea value={postCaption} onChange={e => setPostCaption(e.target.value)} className="w-full p-4 bg-slate-50 border-2 border-transparent focus:border-indigo-500 rounded-2xl outline-none font-bold text-sm h-32" placeholder="O que você quer anunciar?" />
                      <label className="w-full h-32 border-2 border-dashed border-slate-200 rounded-2xl flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-slate-50 transition-all">
                          <input type="file" className="hidden" accept="image/*" onChange={e => {
                              const f = e.target.files?.[0];
                              if (f) { setSelectedFile(f); setPreviewUrl(URL.createObjectURL(f)); }
                          }} />
                          {previewUrl ? <img src={previewUrl} className="h-full w-full object-cover rounded-2xl" /> : (
                              <>
                                  <Camera size={24} className="text-slate-300" />
                                  <span className="text-[10px] font-black uppercase text-slate-400">Anexar Imagem</span>
                              </>
                          )}
                      </label>
                  </div>
                  <div className="p-6 bg-slate-50/50 border-t">
                      <button onClick={handlePostSubmit} disabled={isUploading || (!postCaption && !selectedFile)} className="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black text-xs uppercase shadow-xl active:scale-95 disabled:opacity-50 transition-all">
                          {isUploading ? <Loader2 className="animate-spin" size={18}/> : 'Publicar Agora'}
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
