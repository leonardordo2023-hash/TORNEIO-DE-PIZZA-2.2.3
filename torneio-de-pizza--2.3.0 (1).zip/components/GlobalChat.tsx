
import React from 'react';

// Componente removido do sistema.
export const GlobalChat = () => {
    return null;
};
