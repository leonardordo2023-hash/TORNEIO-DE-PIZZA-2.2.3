
import React from 'react';

const App: React.FC = () => {
  return (
    <div className="p-4 text-center">
        <h1 className="text-xl font-bold">Pizza Tournament Component</h1>
        <p>This is a placeholder component. The main application is in the root App.tsx.</p>
    </div>
  );
};

export default App;
