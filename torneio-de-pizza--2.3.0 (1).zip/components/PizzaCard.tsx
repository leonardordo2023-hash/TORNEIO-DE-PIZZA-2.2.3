
import React, { useEffect, useState, useRef } from 'react';
import { PizzaData, getSum, MediaItem } from '../types';
import { Pizza, Star, UtensilsCrossed, User, Trash2, Check, X, Pencil, MessageSquare } from 'lucide-react';
import { Language, translations } from '../services/translations';

interface PizzaCardProps {
  data: PizzaData;
  userId: string;
  isAdmin: boolean;
  rank?: number;
  peerCount: number;
  index?: number;
  onUpdate: (id: number | string, field: 'beautyScores' | 'tasteScores' | 'beautyScoresDoce' | 'tasteScoresDoce' | 'bonusScores' | 'bonusScoresDoce', value: number) => void;
  onConfirm: (id: number | string) => void;
  onUpdateNote: (id: number | string, note: string) => void;
  onUpdateGlobalNote: (id: number | string, note: string) => void;
  onDelete: (id: number | string) => void;
  onUpdateDate: (id: number | string, date: string) => void;
  onAddPhoto: (id: number | string, item: MediaItem) => void;
  language: Language;
  ownerName?: string;
  variant: 'salgada' | 'doce';
}

const ScoreInput: React.FC<{
  label: string;
  myValue: number | null;
  icon: React.ReactNode;
  onChange: (val: number) => void;
  colorClass: string;
  pointsLabel: string;
  disabled: boolean;
}> = ({ label, myValue, icon, onChange, colorClass, pointsLabel, disabled }) => {
  const [localStr, setLocalStr] = useState(myValue !== null && myValue !== -1 ? myValue.toString() : '');
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    if (myValue === null || myValue === -1) {
        if (localStr !== '') setLocalStr('');
    } else {
        const currentNum = parseFloat(localStr);
        if (currentNum !== myValue) {
            setLocalStr(myValue.toString());
        }
    }
  }, [myValue]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    setLocalStr(raw);
    if (raw === '') { onChange(-1); return; }
    let val = parseFloat(raw);
    if (isNaN(val)) return;
    if (val > 10) val = 10;
    if (val < 0) val = 0;
    onChange(val);
  };

  return (
    <div className={`flex flex-col gap-1 relative transition-all duration-300 ${disabled ? 'opacity-40 grayscale pointer-events-none' : 'opacity-100'}`}>
      <label className="text-[8px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500 flex items-center gap-1 px-1">
        {icon} {label}
      </label>
      <div className={`flex items-center gap-1.5 p-0.5 rounded-lg border transition-all ${isFocused ? 'border-indigo-500 bg-white shadow-sm' : 'border-slate-100 dark:border-slate-800 bg-slate-50/50'}`}>
        <input 
            type="number" 
            min="0" 
            max="10" 
            step="0.1" 
            inputMode="decimal" 
            onFocus={() => setIsFocused(true)}
            onBlur={() => setIsFocused(false)}
            className="w-full bg-transparent p-1.5 text-lg font-black text-center focus:outline-none dark:text-white [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none" 
            placeholder="-" 
            value={localStr} 
            onChange={handleChange}
        />
        <div className="pr-2 font-black text-[8px] text-slate-300">PTS</div>
      </div>
    </div>
  );
};

export const PizzaCard: React.FC<PizzaCardProps> = ({ data, userId, isAdmin, onUpdate, onConfirm, onUpdateNote, onUpdateGlobalNote, rank, peerCount, index = 0, onDelete, onUpdateDate, onAddPhoto, language, ownerName, variant }) => {
  const [isVisible, setIsVisible] = useState(false);
  const t = translations[language];
  
  useEffect(() => { 
      const timer = setTimeout(() => setIsVisible(true), 30 + (index * 20)); 
      return () => clearTimeout(timer);
  }, [index]);

  const isSalgada = variant === 'salgada';
  const beautyScoresMap = isSalgada ? data.beautyScores : (data.beautyScoresDoce || {});
  const tasteScoresMap = isSalgada ? data.tasteScores : (data.tasteScoresDoce || {});
  const bonusScoresMap = isSalgada ? (data.bonusScores || {}) : (data.bonusScoresDoce || {});

  const totalPointsVal = getSum(beautyScoresMap) + getSum(tasteScoresMap) + getSum(bonusScoresMap);
  const myBeauty = beautyScoresMap?.[userId] ?? null;
  const myTaste = tasteScoresMap?.[userId] ?? null;
  const myBonus = bonusScoresMap?.[userId] ?? 0;
  
  const isConfirmed = data.confirmedVotes?.[userId] === true;
  const hasMyVotes = (myBeauty !== null && myBeauty !== -1) && (myTaste !== null && myTaste !== -1);

  return (
    <div className={`transition-all duration-300 transform ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/60 dark:border-slate-800/60 shadow-md overflow-hidden flex flex-col h-full relative">
          
          <div className="p-3 pb-1 flex justify-between items-start">
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${isSalgada ? 'bg-orange-100 text-orange-600' : 'bg-pink-100 text-pink-600'}`}>
                <Pizza size={16} />
              </div>
              <div>
                <h3 className="text-sm font-black text-slate-800 dark:text-white leading-none">Pizza #{data.id}</h3>
                <span className="text-[7px] font-black uppercase text-indigo-500 tracking-tighter">{ownerName || 'Voto'}</span>
              </div>
            </div>
            {totalPointsVal > 0 && (
                <div className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md text-[10px] font-black text-slate-700">
                  {totalPointsVal.toFixed(1)}
                </div>
            )}
          </div>

          <div className="p-3 pt-1 grid grid-cols-2 gap-2">
              <ScoreInput label={t.beauty} myValue={myBeauty} icon={<Star size={8} />} colorClass="" onChange={(val) => onUpdate(data.id, isSalgada ? 'beautyScores' : 'beautyScoresDoce', val)} pointsLabel="" disabled={isConfirmed} />
              <ScoreInput label={t.taste} myValue={myTaste} icon={<UtensilsCrossed size={8} />} colorClass="" onChange={(val) => onUpdate(data.id, isSalgada ? 'tasteScores' : 'tasteScoresDoce', val)} pointsLabel="" disabled={isConfirmed} />
          </div>
          
          <div className="px-3 pb-2 relative group">
              <button 
                onClick={() => onConfirm(data.id)} 
                disabled={!hasMyVotes || isConfirmed} 
                className={`w-full py-2 rounded-lg font-black text-[9px] uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${isConfirmed ? 'bg-green-50 text-green-600 border border-green-100' : !hasMyVotes ? 'bg-slate-50 text-slate-300' : 'bg-slate-900 text-white shadow-lg'}`}
              >
                  {isConfirmed && <Check size={12} strokeWidth={3} />} {isConfirmed ? t.voteSent : t.voteButton}
              </button>
              <span className="absolute top-full mt-1 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-[8px] font-black px-2 py-0.5 rounded shadow-xl whitespace-nowrap z-50 pointer-events-none uppercase tracking-widest border border-white/10">Confirmar Voto</span>
          </div>

          <div className="p-3 pt-0 space-y-2">
            <textarea 
                className="w-full text-[9px] font-bold p-2 rounded-lg border border-slate-100 dark:border-slate-800 bg-slate-50/50 outline-none transition-all resize-none h-8" 
                rows={1} 
                value={data.userNotes?.[userId] || ''} 
                onChange={(e) => onUpdateNote(data.id, e.target.value)} 
                placeholder={t.yourNotes} 
            />
            <textarea 
                className="w-full text-[9px] font-bold p-2 rounded-lg border border-blue-50 dark:border-blue-900/30 bg-blue-50/20 outline-none transition-all resize-none h-8" 
                rows={1} 
                value={data.notes || ''} 
                onChange={(e) => onUpdateGlobalNote(data.id, e.target.value)} 
                placeholder={t.globalNotes} 
            />
          </div>
        </div>
    </div>
  );
};
